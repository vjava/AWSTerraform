import json

def lambda_handler(event, context):
    print("Received S3 Event Notification via EventBridge!")
    print("Event Payload:", json.dumps(event))
    
    detail = event.get('detail', {})
    bucket_name = detail.get('bucket', {}).get('name')
    object_key = detail.get('object', {}).get('key')
    
    print(f"File Successfully Processed: s3://{bucket_name}/{object_key}")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Event successfully processed by Lambda!')
    }
