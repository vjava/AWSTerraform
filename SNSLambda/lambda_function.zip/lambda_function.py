import json
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info("Received event from SNS!")
    
    for record in event.get('Records', []):
        sns_data = record.get('Sns', {})
        subject = sns_data.get('Subject', 'No Subject')
        message = sns_data.get('Message', 'No Message')
        message_id = sns_data.get('MessageId', '')
        
        logger.info(f"Processed SNS MessageId: {message_id}")
        logger.info(f"Subject: {subject} | Payload: {message}")
        
    return {
        'statusCode': 200,
        'body': json.dumps('SNS Event Processed Successfully!')
    }